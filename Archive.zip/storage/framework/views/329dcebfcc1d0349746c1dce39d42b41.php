<script>

</script>
<?php /**PATH /Users/lavumweemba/Documents/laravel-apps/silham_project/silhamconsultingservices/resources/views/partials/js/custom_js.blade.php ENDPATH**/ ?>