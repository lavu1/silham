
<script src="<?php echo e(asset('assets/js/vendors.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>

<?php echo $__env->make('partials.js.custom_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/lavumweemba/Documents/laravel-apps/silham_project/silhamconsultingservices/resources/views/partials/inc_bottom.blade.php ENDPATH**/ ?>