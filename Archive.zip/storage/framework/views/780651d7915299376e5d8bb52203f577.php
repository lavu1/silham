<?php $__env->startSection('page_title', 'Home'); ?>
<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lavumweemba/Documents/laravel-apps/silham_project/silhamconsultingservices/resources/views/pages/home.blade.php ENDPATH**/ ?>