@extends('layouts.master')
@section('page_title', 'Home')
@section('content')


@endsection
