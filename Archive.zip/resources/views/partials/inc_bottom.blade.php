
<script src="{{ asset('assets/js/vendors.bundle.js') }}"></script>
<script src="{{ asset('assets/js/scripts.js')}}"></script>

@include('partials.js.custom_js')
